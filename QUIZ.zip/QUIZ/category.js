const categoryBtns = document.querySelectorAll(".category-btn");
const greeting = document.getElementById("greeting");
const backBtn = document.getElementById("back-btn");
const questions = {
    sports: [
        {
        question: "What distance do marathon participants run?",
        option: {
           A: "10 Kilometres",
           B:  "21 Kilometres",
           C:  "42,195 Kilometres",
           D:  "100 Kilometres"
        },
        answer: "C"
    },
    {
    question: "What material is used for weights in most bicycle races?",
        option: {
           A: "Lead",
           B:  "Glass",
           C:  "Aluminium",
           D:  "Concrete"
        },
        answer: "A"
    },
    {
    question: "Which team won the last World Hockey Championship?",
        option: {
           A: "Russia",
           B:  "Canada",
           C:  "United States",
           D:  "Finland"
        },
        answer: "B"
    },
    {
        question: "What sport is considered the most popular in the world?",
            option: {
               A: "Football",
               B:  "Tennis",
               C:  "Golf",
               D:  "Basketball"
            },
            answer: "A"
        },

        {
    question: "What year is officially recognized as the beginning of the modern Olympic Games?",
        option: {
           A: "1886",
           B:  "1896",
           C:  "1906",
           D:  "1916"
        },
        answer: "B"
    },

    {
        question: "In what country was boxer Muhammed Ali born?",
            option: {
               A: "United States",
               B:  "United Kingdom",
               C:  "Canada",
               D:  "Jamaica"
            },
            answer: "A"
        },
    

],
    fashion: [
    {
        question: "A souter is a maker of what?",
        option: {
           A: "Shoes", 
           B: "Bags", 
           C: "Clothes",
           D: "Jewelries"
    },
        answer: "A"
    },

    {
        question: "What is the term for clothing that is quickly produced and sold at low cost?",
        option: {
           A: "Haute Couture", 
           B: "Ready-to-wear", 
           C: "Fast Fashion",
           D: "Bespoke"
    },
        answer: "C"
    },

    {
        question: "Which decade is often associated with the rise of the miniskirt?",
        option: {
           A: "1950s", 
           B: "1960s", 
           C: "1970s",
           D: "1980s"
    },
        answer: "B"
    },

    {
        question: "What is the name of the luxury fashion brand known for its interlocking 'CC' logo?",
        option: {
           A: "Gucci", 
           B: "Prada", 
           C: "Chanel",
           D: "Louis Vuitton"
    },
        answer: "C"
    },

    {
        question: "What fabric is commonly used in the creation of trench coats?",
        option: {
           A: "Silk", 
           B: "Linen", 
           C: "Gabardine",
           D: "Denim"
    },
        answer: "C"
    },

    {
        question: "Which fashion magazine is known for its annual Met Gala?",
        option: {
           A: "Vogue", 
           B: "Harper's Bazaar", 
           C: "Elle",
           D: "Marie Claire"
    },
        answer: "A"
    }
],
    food: [
    {
      question: "Which country drinks the most coffee per capita?",  
      option: {
       A: "Ireland", 
       B: "Finland", 
       C: "Italy",
       D: "Congo"
    },  
      answer: "B"
    },

    {
        question: "How many measures of Gordon’s Gin are in a Vesper (James Bond) martini?",  
        option: {
         A: "1", 
         B: "2", 
         C: "3",
         D: "4"
      },  
        answer: "C"
      },

      {
        question: "Cacio e pepe is a staple of what Italian city’s cuisine?",  
        option: {
         A: "Rome", 
         B: "Spain", 
         C: "Italy",
         D: "Germany"
      },  
        answer: "A"
      },
      {
        question: "Where did sushi originate?",  
        option: {
         A: "Japan", 
         B: "Spain", 
         C: "Italy",
         D: "Germany"
      },  
        answer: "A"
      },

      {
        question: "Pink Ladies and Granny Smiths are types of what fruit?",  
        option: {
         A: "Watermelon", 
         B: "Pineapple", 
         C: "Apple",
         D: "Berry"
      },  
        answer: "C"
      },

      {
        question: "What meat is used in a shepherd's pie?",  
        option: {
         A: "Duck", 
         B: "Lamb", 
         C: "Goat",
         D: "Chicken"
      },  
        answer: "B"
      },
],
    health: [
    {
        question: "What is the recommended daily water intake for adults?",  
        option: {
           A: "2 cups", 
           B: "4 cups", 
           C: "8 cups",
           D: "12 cups"
        }, 
        answer: "C" 
      },
    {
        question: "What is the average recommended sleep duration for adults?",  
        option: {
           A: "4 hours", 
           B: "6 hours", 
           C: "8  8 hours",
           D: "10 hours"
        }, 
        answer: "C" 
      },

      {
        question: "Which nutrient is responsible for building and repairing body tissues?",
        option: {
          A: "Carbohydrates",
          B: "Proteins",
          C: "Fats",
          D: "Vitamins"
        },
        answer: "B"
        },

        {
          question: "Which of the following is a good source of vitamin C?",
          option: {
            A: "Oranges",
            B: "Eggs",
            C: "Beef",
            D: "Whole grains"
          },
          answer: "A"
          },

          {
            question: "Which exercise is beneficial for cardiovascular health?",
            option: {
              A: "Running",
              B: "Weightlifting",
              C: "Yoga",
              D: "Stetching",
            },
            answer: "A"
          },

          {
            question: "Which of the following is a symptom of dehydration?",
            option: {
              A: "Headache",
              B: "Excessive thirst",
              C: "Fatigue",
              D: "All of the above",
            },
            answer: "D"
          }
  
  ],
    technology: [
      {
          question: "What does HTML stand for?",  
          option: {
             A: "HyperText Markup Language ", 
             B: "High-Level Text Language", 
             C: "Hyperlink and Text Markup Language",
             D: "Home Tool Markup Language"
          },  
          answer: "A"
        },
      {
          question: "Which tag is used to create a hyperlink in HTML?",  
          option: {
             A: "<link>", 
             B: "<a>", 
             C: "<hyperlink>",
             D: "<href>"
          },  
          answer: "B"
        },
      {
          question: "Which of the following is NOT a valid way to declare a variable in JavaScript?",  
          option: {
             A: "var x = 10;", 
             B: "let y = 'hello';", 
             C: "const z = true;",
             D: "integer a = 5;"
          },  
          answer: "A"
        },
      {
          question: "What does CSS stand for?",  
          option: {
             A: "Computer Style Sheets", 
             B: "Creative Style Sheets", 
             C: "Cascading Style Sheets",
             D: "Colorful Style Sheets"
          },  
          answer: "C"
        },
      {
          question: "Which symbol is used to denote a single-line comment in Python?",  
          option: {
             A: " //", 
             B: "/**/", 
             C: "#",
             D: "<!-->"
          },  
          answer: "C"
        },
      {
          question: "What does IDE stand for?",  
          option: {
             A: "Integrated Development Environment", 
             B: "Internet Data Entry", 
             C: " Internal Drive Encoder",
             D: "Home Tool Markup Language"
          },  
          answer: "A"
        },
    ],  

    fun: [
      {
        question: "How many ghosts chase Pac-Man at the start of each game?",  
        option: {
           A: "1", 
           B: "2", 
           C: "3",
           D: "4"
        },  
        answer: "D"
      },

      {
        question: "What character have both Robert Downey Jr. and Benedict Cumberbatch played?",  
        option: {
           A: "Peter Parker", 
           B: "Tyler Perry", 
           C: "Idris Elba",
           D: "Sherlock Holmes"
        },  
        answer: "D"
      },

      {
        question: "In which country was Elon Musk born?",  
        option: {
           A: "Spain", 
           B: "United States", 
           C: "South Africa",
           D: "Turkey"
        },  
        answer: "C"
      },

      {
        question: "Who performs the voice of Homer Simpson?",  
        option: {
           A: "Jenna Ortega", 
           B: "Brec Bassinger", 
           C: "Dan Castellaneta",
           D: "Selena Gomez"
        },  
        answer: "C"
      },

      {
        question: "What Netflix show had the most streaming views in 2021?",  
        option: {
           A: "Without Remorse", 
           B: "Venom: Let There Be Carnage", 
           C: "Red Notice",
           D: "Squid Game"
        },  
        answer: "D"
      },
],  
}  

// Event Listener for the category selection
categoryBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
    // Get selected category for data attribute
        const selectedCategory = btn.getAttribute("data-category")
        //Load and validate questions
        const allQuestions = questions[selectedCategory];
        // Validate each question for each category
        if(!allQuestions || allQuestions.length === 0) {
            alert("No question found for this category");
            return;
        }
    // Save questions and category to localStorage
    // Save selected questions to localStorage
    localStorage.setItem("allQuestions", JSON.stringify(allQuestions));
    // save the category for later
    localStorage.setItem("category", selectedCategory);
    // Redirect to quiz page
    window.location.href = "quiz.html";
        });
    })
    // Back to welcome screen
    backBtn.addEventListener("click", () => {
        window.location.href = "index.html";
    });
    // Get name from storage and show in category
    const username = localStorage.getItem("username");
    if(username) {
        greeting.textContent = `Welcome back, ${username}`;
        setTimeout(() => {
            // Remove greetings after 4 seconds
                greeting.classList.add("greeting-hide");
            setTimeout(() => {
                // Remove after 4 seconds
                greeting.style.display = "none";
            }, 500);
        }, 4000);
    } else {
        // Redirect back to homepage if name isn't present
        window.location.href = "index.html";
    }