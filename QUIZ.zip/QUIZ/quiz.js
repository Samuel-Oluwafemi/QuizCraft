const welcomeScreen = document.getElementById("welcome-screen");
const startBtn = document.getElementById("start-btn");
const quizContainer = document.getElementById("quiz-container");
const usernameInput = document.getElementById("username");
const questionEl = document.getElementById("question");
const optionBtns = document.querySelectorAll(".option");
const nextBtn = document.getElementById("next-btn");
const prevBtn = document.getElementById("prev-btn");
const backBtn = document.getElementById("back-btn");
const restartBtn = document.getElementById("restart-btn");
const submitBtn = document.getElementById("submit-btn");
const popup = document.getElementById("popup"); 
const popupMsg = document.getElementById("popup-message"); 
const resultBox = document.getElementById("result-box");
const resultMsg = document.getElementById("result-msg");
const ScoreTxt = document.getElementById("score-text");

// Get stored user data & selected quiz
const user = localStorage.getItem("username");
const selectedCategory = localStorage.getItem("category");
const questions = JSON.parse(localStorage.getItem("allQuestions"));
//if no category was found, send user back
if(!user || !selectedCategory || !questions ||questions.length === 0) {
    alert("Please enter your name and select a category");
    window.location.href = "welcomescreen.html";
} else {
    quizContainer.style.display = "block";
}

// Show Welcome user before the quiz
greeting.textContent = `Let's Rock, ${user}${"!"}
${selectedCategory}`;
setTimeout(() => {
    // Remove greetings after 4 seconds
        greeting.classList.add("greeting-hide");
    setTimeout(() => {
        // Remove after 4 seconds
        greeting.style.display = "none";
    }, 500);
}, 4000);

// Starts the quiz from the first question
//Increases or decreases when user clicks Next or Previous.
let currentIndex = 0;
let score = 0;

// Display the current question
function displayQuestion() {
    const currentQ = questions[currentIndex];
    questionEl.textContent = `${currentIndex + 1}. ${currentQ.question}`;
    // For option 
    optionBtns.forEach((btn) => {
        const letter = btn.getAttribute("data-letter");
        //This sets the button text
        btn.textContent = `${letter}: ${currentQ.option[letter]}`;
        // This resets any old styles
        btn.classList.remove("correct", "wrong");
        btn.style.backgroundColor = "";
        btn.disabled = false;
        // Show submit btn on the last question only
        if(currentIndex === questions.length - 1) {
            submitBtn.style.display = "inline-block";
            nextBtn.style.display = "none";
        } else {
            submitBtn.style.display = "none";
            nextBtn.style.display = "inline-block";
        };
    });
}

// Handle answer selection
optionBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        const selected = btn.getAttribute("data-letter");
        const currentQ = questions[currentIndex];

        if(selected === currentQ.answer) {
            btn.style.backgroundColor = "green";
            score++;
            showPopup("Correct!", "green");
        } else {
            btn.style.backgroundColor = "red";
            showPopup("Wrong!", "red");
        }

        // Disable all buttons after selection
        optionBtns.forEach(b => b.disabled = true);

    });
});

// For popup msg
function showPopup(message, color) {
    popupMsg.textContent = message;
    popup.style.backgroundColor = color;
    popup.style.display ="block";

    setTimeout(() => {
        popup.style.display = "none";
    }, 2000); 
}

// Submit answer selection
submitBtn.addEventListener("click", () => {
    //Hide the quiz container
    document.getElementById("quiz-container").style.display = "none";
    // Show the result section - Unhide the result box
    resultBox.style.display = "block";
    // Show the final score
    ScoreTxt.textContent = `You got ${score} out of ${questions.length}`;
    //DIsplay a custom msg based on score
    if(score === questions.length) {
        resultMsg.textContent = "Excellent!, You are Incredible";
        resultMsg.style.color = "green";
    } else if(score >= questions.length / 2) {
        resultMsg.textContent = "Well done!, Keep up the good work";
        resultMsg.style.color = "orange";
    } else {
        resultMsg.textContent = "Try again! You can do better";
        resultMsg.style.color = "red";
    }
});
// Next button
nextBtn.addEventListener("click", () => {
    if (currentIndex < questions.length - 1) {
        currentIndex++;// Move to the next question
        displayQuestion();
    }
});

// Previous button
prevBtn.addEventListener("click", () => {
  if (currentIndex > 0) {
    currentIndex--;// go back to the prev question
    displayQuestion();
  }
});

// Restart button
restartBtn.addEventListener("click", () => {
    location.reload();
});

backBtn.addEventListener("click", () => {
    window.location.href = "category.html";
})
// Start with the first question
displayQuestion();

