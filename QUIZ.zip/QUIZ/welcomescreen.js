const welcomeScreen = document.getElementById("welcome-screen");
const startBtn = document.getElementById("start-btn");
const usernameInput = document.getElementById("username");

// Show Welcome user before the quiz
//Create a variable for user name
  let userName = "";
//Add a click btn to start quiz
startBtn.addEventListener("click", () => {
    const name = usernameInput.value.trim(); //Get the user's input
    if(name === "") {
        alert("PLEASE ENTER YOUR NAME TO START THE QUIZ");
        return; // Validation: Validate the name
    } 
    // Store name
    userName = name;  
    // Save the name to LocalStorage
    localStorage.setItem("username", name);
    // Redirect to the category selection page
    window.location.href = "category.html";
    //Get back the saved category
    // Hide welcome screen
    welcomeScreen.style.display = "none";
    // Show quiz area 
    quizContainer.style.display = "block" 
    // Display greeting
    greeting.textContent = `Welcome back, ${name}${"!"}`;
    setTimeout(() => {
        // Remove greetings after 4 seconds
        greeting.classList.add("greeting-hide");
    setTimeout(() => {
        // Remove after 4 seconds
        greeting.style.display = "none";

    }, 500);
    }, 4000);
});
